#!python

"""
A really simple script just to demonstrate packaging
"""

import sys, os
from capitalize import main
from capitalize import capital_mod


if __name__ == "__main__":
    main.main()    
